var files_dup =
[
    [ "Candidats.cpp", "_candidats_8cpp.html", null ],
    [ "Candidats.h", "_candidats_8h.html", [
      [ "Candidats", "class_candidats.html", "class_candidats" ]
    ] ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "Solucio.cpp", "_solucio_8cpp.html", null ],
    [ "Solucio.h", "_solucio_8h.html", [
      [ "Solucio", "class_solucio.html", "class_solucio" ]
    ] ],
    [ "Solucionador.cpp", "_solucionador_8cpp.html", null ],
    [ "Solucionador.h", "_solucionador_8h.html", [
      [ "Solucionador", "class_solucionador.html", "class_solucionador" ]
    ] ]
];