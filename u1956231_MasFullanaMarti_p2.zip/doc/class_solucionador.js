var class_solucionador =
[
    [ "Solucionador", "class_solucionador.html#a2066e2b9289f31a666d7360072af6824", null ],
    [ "backtrackingMillor", "class_solucionador.html#a7e215be6d45cf577cf7d6fd9c37df91d", null ],
    [ "backtrackingUna", "class_solucionador.html#ab7047ba77455e191bce6049df4e9d3c2", null ],
    [ "get_MillorSolucio", "class_solucionador.html#a7df7e306414efd87f674a92e245c4a24", null ],
    [ "get_time", "class_solucionador.html#acb086757f1f206b64ba84b7b863931cc", null ],
    [ "get_UnaSolucio", "class_solucionador.html#afd70f11e75131ee1c83ab40c26c30afe", null ],
    [ "solucionarMillor", "class_solucionador.html#a662660418eea025be73390e061d744cc", null ],
    [ "solucionarUna", "class_solucionador.html#a189d7ab19568a4da549d9b8e8694e43b", null ],
    [ "encertat", "class_solucionador.html#a587006540d8bfa558aad1e3d147b2c65", null ],
    [ "solAct", "class_solucionador.html#ab9070154905cb361553d5659a84b886e", null ],
    [ "solOpt", "class_solucionador.html#a11bc956d51e901362f49d6765a9cc3ac", null ],
    [ "t1", "class_solucionador.html#a6574480b19395f21f54e905ae80bc3b1", null ],
    [ "t2", "class_solucionador.html#a2e2c5797830bb5854603bd194cc912b1", null ]
];