var searchData=
[
  ['nivell_31',['nivell',['../class_solucio.html#ac6ca6e24b91e41bd6c3c13426be0335c',1,'Solucio']]]
];
