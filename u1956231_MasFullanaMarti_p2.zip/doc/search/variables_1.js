var searchData=
[
  ['encertat_93',['encertat',['../class_solucionador.html#a587006540d8bfa558aad1e3d147b2c65',1,'Solucionador']]]
];
