var searchData=
[
  ['matsumes_95',['matSumes',['../class_solucio.html#a02da702f0ee1de189cb085d14313ed80',1,'Solucio']]],
  ['mida_96',['mida',['../class_solucio.html#a51bdf126d3d8c0c1aa67b775585ee1f8',1,'Solucio']]]
];
