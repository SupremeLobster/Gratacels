var searchData=
[
  ['get_5fmillorsolucio_74',['get_MillorSolucio',['../class_solucionador.html#a7df7e306414efd87f674a92e245c4a24',1,'Solucionador']]],
  ['get_5ftime_75',['get_time',['../class_solucionador.html#acb086757f1f206b64ba84b7b863931cc',1,'Solucionador']]],
  ['get_5funasolucio_76',['get_UnaSolucio',['../class_solucionador.html#afd70f11e75131ee1c83ab40c26c30afe',1,'Solucionador']]]
];
