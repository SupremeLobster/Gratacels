var searchData=
[
  ['inicialitzarcandidats_77',['inicialitzarCandidats',['../class_solucio.html#a00e64a357a95d6645d4309d71513a380',1,'Solucio']]]
];
