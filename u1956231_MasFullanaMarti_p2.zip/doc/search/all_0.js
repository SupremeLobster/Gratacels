var searchData=
[
  ['a_5fmaxim_0',['a_maxim',['../class_candidats.html#a57b5212577f4fe4d3b077b6b06527d8f',1,'Candidats']]],
  ['acceptable_1',['acceptable',['../class_solucio.html#aace918db9fa56850d988113b24c6cd68',1,'Solucio']]],
  ['acolumnes_2',['aColumnes',['../class_solucio.html#a8723b0d2138931692e4e9fd446d9734c',1,'Solucio']]],
  ['actual_3',['actual',['../class_candidats.html#a69bd68ac03663d4c55822e9314dd2fc8',1,'Candidats']]],
  ['afiles_4',['aFiles',['../class_solucio.html#a47bcb20085c64b131dcd518442edd00c',1,'Solucio']]],
  ['alcada_5ftotal_5',['alcada_total',['../class_solucio.html#a72776ca31f9452f498ef0f527a19c631',1,'Solucio']]],
  ['alcades_6',['alcades',['../class_solucio.html#a4d080ec896837ac9a5effa626ea92d3f',1,'Solucio']]],
  ['amax_7',['aMax',['../class_solucio.html#ac32e805fb030ca867d01691e41f15f53',1,'Solucio']]],
  ['anotarcandidat_8',['anotarCandidat',['../class_solucio.html#abe2cb23b9cf6c471aeb17f44a774eec1',1,'Solucio']]]
];
