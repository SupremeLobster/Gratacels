var searchData=
[
  ['seguent_82',['seguent',['../class_candidats.html#afd756250ad98135ef7988ab84e16e050',1,'Candidats']]],
  ['solucio_83',['Solucio',['../class_solucio.html#a83a8a2881f78b7e406761e532d23f2a6',1,'Solucio::Solucio()'],['../class_solucio.html#a1eec4b2e9df961351c665ee42e72bb89',1,'Solucio::Solucio(ifstream &amp;fin, int alcada_max, bool trobarMillor)']]],
  ['solucionador_84',['Solucionador',['../class_solucionador.html#a2066e2b9289f31a666d7360072af6824',1,'Solucionador']]],
  ['solucionarmillor_85',['solucionarMillor',['../class_solucionador.html#a662660418eea025be73390e061d744cc',1,'Solucionador']]],
  ['solucionaruna_86',['solucionarUna',['../class_solucionador.html#a189d7ab19568a4da549d9b8e8694e43b',1,'Solucionador']]]
];
