var searchData=
[
  ['solucio_2ecpp_59',['Solucio.cpp',['../_solucio_8cpp.html',1,'']]],
  ['solucio_2eh_60',['Solucio.h',['../_solucio_8h.html',1,'']]],
  ['solucionador_2ecpp_61',['Solucionador.cpp',['../_solucionador_8cpp.html',1,'']]],
  ['solucionador_2eh_62',['Solucionador.h',['../_solucionador_8h.html',1,'']]]
];
