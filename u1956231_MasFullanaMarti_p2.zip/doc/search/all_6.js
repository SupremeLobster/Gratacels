var searchData=
[
  ['ican_23',['iCan',['../class_candidats.html#ade5f1e814c267d44c8980c6fa718491c',1,'Candidats']]],
  ['inicialitzarcandidats_24',['inicialitzarCandidats',['../class_solucio.html#a00e64a357a95d6645d4309d71513a380',1,'Solucio']]]
];
