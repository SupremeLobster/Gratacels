var searchData=
[
  ['seguent_33',['seguent',['../class_candidats.html#afd756250ad98135ef7988ab84e16e050',1,'Candidats']]],
  ['sol_34',['sol',['../class_solucio.html#aacb93dc73ad1e901abaee0817c346937',1,'Solucio']]],
  ['solact_35',['solAct',['../class_solucionador.html#ab9070154905cb361553d5659a84b886e',1,'Solucionador']]],
  ['solopt_36',['solOpt',['../class_solucionador.html#a11bc956d51e901362f49d6765a9cc3ac',1,'Solucionador']]],
  ['solucio_37',['Solucio',['../class_solucio.html',1,'Solucio'],['../class_solucio.html#a83a8a2881f78b7e406761e532d23f2a6',1,'Solucio::Solucio()'],['../class_solucio.html#a1eec4b2e9df961351c665ee42e72bb89',1,'Solucio::Solucio(ifstream &amp;fin, int alcada_max, bool trobarMillor)']]],
  ['solucio_2ecpp_38',['Solucio.cpp',['../_solucio_8cpp.html',1,'']]],
  ['solucio_2eh_39',['Solucio.h',['../_solucio_8h.html',1,'']]],
  ['solucionador_40',['Solucionador',['../class_solucionador.html',1,'Solucionador'],['../class_solucionador.html#a2066e2b9289f31a666d7360072af6824',1,'Solucionador::Solucionador()']]],
  ['solucionador_2ecpp_41',['Solucionador.cpp',['../_solucionador_8cpp.html',1,'']]],
  ['solucionador_2eh_42',['Solucionador.h',['../_solucionador_8h.html',1,'']]],
  ['solucionarmillor_43',['solucionarMillor',['../class_solucionador.html#a662660418eea025be73390e061d744cc',1,'Solucionador']]],
  ['solucionaruna_44',['solucionarUna',['../class_solucionador.html#a189d7ab19568a4da549d9b8e8694e43b',1,'Solucionador']]]
];
