var searchData=
[
  ['solucio_54',['Solucio',['../class_solucio.html',1,'']]],
  ['solucionador_55',['Solucionador',['../class_solucionador.html',1,'']]]
];
