var searchData=
[
  ['acceptable_63',['acceptable',['../class_solucio.html#aace918db9fa56850d988113b24c6cd68',1,'Solucio']]],
  ['actual_64',['actual',['../class_candidats.html#a69bd68ac03663d4c55822e9314dd2fc8',1,'Candidats']]],
  ['anotarcandidat_65',['anotarCandidat',['../class_solucio.html#abe2cb23b9cf6c471aeb17f44a774eec1',1,'Solucio']]]
];
