var searchData=
[
  ['t1_101',['t1',['../class_solucionador.html#a6574480b19395f21f54e905ae80bc3b1',1,'Solucionador']]],
  ['t2_102',['t2',['../class_solucionador.html#a2e2c5797830bb5854603bd194cc912b1',1,'Solucionador']]]
];
