var searchData=
[
  ['a_5fmaxim_87',['a_maxim',['../class_candidats.html#a57b5212577f4fe4d3b077b6b06527d8f',1,'Candidats']]],
  ['acolumnes_88',['aColumnes',['../class_solucio.html#a8723b0d2138931692e4e9fd446d9734c',1,'Solucio']]],
  ['afiles_89',['aFiles',['../class_solucio.html#a47bcb20085c64b131dcd518442edd00c',1,'Solucio']]],
  ['alcada_5ftotal_90',['alcada_total',['../class_solucio.html#a72776ca31f9452f498ef0f527a19c631',1,'Solucio']]],
  ['alcades_91',['alcades',['../class_solucio.html#a4d080ec896837ac9a5effa626ea92d3f',1,'Solucio']]],
  ['amax_92',['aMax',['../class_solucio.html#ac32e805fb030ca867d01691e41f15f53',1,'Solucio']]]
];
