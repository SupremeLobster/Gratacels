var searchData=
[
  ['encertat_17',['encertat',['../class_solucionador.html#a587006540d8bfa558aad1e3d147b2c65',1,'Solucionador']]],
  ['esfi_18',['esFi',['../class_candidats.html#afa7c56676a8c4f433c77f661600b35c8',1,'Candidats']]],
  ['esmillor_19',['esMillor',['../class_solucio.html#a2e6647a2cb565459198b2980a388d53f',1,'Solucio']]]
];
