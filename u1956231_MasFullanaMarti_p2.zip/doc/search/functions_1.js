var searchData=
[
  ['backtrackingmillor_66',['backtrackingMillor',['../class_solucionador.html#a7e215be6d45cf577cf7d6fd9c37df91d',1,'Solucionador']]],
  ['backtrackinguna_67',['backtrackingUna',['../class_solucionador.html#ab7047ba77455e191bce6049df4e9d3c2',1,'Solucionador']]]
];
