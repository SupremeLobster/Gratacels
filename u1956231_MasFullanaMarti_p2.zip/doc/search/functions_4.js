var searchData=
[
  ['esfi_72',['esFi',['../class_candidats.html#afa7c56676a8c4f433c77f661600b35c8',1,'Candidats']]],
  ['esmillor_73',['esMillor',['../class_solucio.html#a2e6647a2cb565459198b2980a388d53f',1,'Solucio']]]
];
