var searchData=
[
  ['desanotarcandidat_16',['desanotarCandidat',['../class_solucio.html#af2170a9a52a0fe028b149fa6b4e25c22',1,'Solucio']]]
];
