var searchData=
[
  ['main_25',['main',['../main_8cpp.html#a1dfeea39dabf076270426c94def1a2a2',1,'main.cpp']]],
  ['main_2ecpp_26',['main.cpp',['../main_8cpp.html',1,'']]],
  ['matsumes_27',['matSumes',['../class_solucio.html#a02da702f0ee1de189cb085d14313ed80',1,'Solucio']]],
  ['mida_28',['mida',['../class_solucio.html#a51bdf126d3d8c0c1aa67b775585ee1f8',1,'Solucio']]],
  ['mostrar_29',['mostrar',['../class_solucio.html#aceda78a3c2cfee7f456c8d10e80a3e49',1,'Solucio']]],
  ['mostrarajuda_30',['mostrarAjuda',['../main_8cpp.html#ac264e2a673397b3e4d070b625f8e4330',1,'main.cpp']]]
];
