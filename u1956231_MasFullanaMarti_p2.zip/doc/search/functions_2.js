var searchData=
[
  ['calcularmatriusumes_68',['calcularMatriuSumes',['../class_solucio.html#ae368c9ae97f900cef03c64269a422f12',1,'Solucio']]],
  ['candidats_69',['Candidats',['../class_candidats.html#accd7f4aa75c1b102a54a556ee7aa77f6',1,'Candidats']]],
  ['completa_70',['completa',['../class_solucio.html#adf12823d6437ac4bb638c9f27caf1078',1,'Solucio']]]
];
