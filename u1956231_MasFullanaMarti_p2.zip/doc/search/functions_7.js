var searchData=
[
  ['main_78',['main',['../main_8cpp.html#a1dfeea39dabf076270426c94def1a2a2',1,'main.cpp']]],
  ['mostrar_79',['mostrar',['../class_solucio.html#aceda78a3c2cfee7f456c8d10e80a3e49',1,'Solucio']]],
  ['mostrarajuda_80',['mostrarAjuda',['../main_8cpp.html#ac264e2a673397b3e4d070b625f8e4330',1,'main.cpp']]]
];
