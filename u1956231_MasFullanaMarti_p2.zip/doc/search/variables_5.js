var searchData=
[
  ['sol_98',['sol',['../class_solucio.html#aacb93dc73ad1e901abaee0817c346937',1,'Solucio']]],
  ['solact_99',['solAct',['../class_solucionador.html#ab9070154905cb361553d5659a84b886e',1,'Solucionador']]],
  ['solopt_100',['solOpt',['../class_solucionador.html#a11bc956d51e901362f49d6765a9cc3ac',1,'Solucionador']]]
];
