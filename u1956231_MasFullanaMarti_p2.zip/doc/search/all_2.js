var searchData=
[
  ['calcularmatriusumes_11',['calcularMatriuSumes',['../class_solucio.html#ae368c9ae97f900cef03c64269a422f12',1,'Solucio']]],
  ['candidats_12',['Candidats',['../class_candidats.html',1,'Candidats'],['../class_candidats.html#accd7f4aa75c1b102a54a556ee7aa77f6',1,'Candidats::Candidats()']]],
  ['candidats_2ecpp_13',['Candidats.cpp',['../_candidats_8cpp.html',1,'']]],
  ['candidats_2eh_14',['Candidats.h',['../_candidats_8h.html',1,'']]],
  ['completa_15',['completa',['../class_solucio.html#adf12823d6437ac4bb638c9f27caf1078',1,'Solucio']]]
];
