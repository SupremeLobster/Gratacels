var searchData=
[
  ['potsermillor_32',['potSerMillor',['../class_solucio.html#a4c18908503c0586d568dab5afbe2171b',1,'Solucio']]]
];
