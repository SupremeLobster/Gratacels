var class_candidats =
[
    [ "Candidats", "class_candidats.html#accd7f4aa75c1b102a54a556ee7aa77f6", null ],
    [ "actual", "class_candidats.html#a69bd68ac03663d4c55822e9314dd2fc8", null ],
    [ "esFi", "class_candidats.html#afa7c56676a8c4f433c77f661600b35c8", null ],
    [ "seguent", "class_candidats.html#afd756250ad98135ef7988ab84e16e050", null ],
    [ "a_maxim", "class_candidats.html#a57b5212577f4fe4d3b077b6b06527d8f", null ],
    [ "iCan", "class_candidats.html#ade5f1e814c267d44c8980c6fa718491c", null ]
];