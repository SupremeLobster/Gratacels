var annotated_dup =
[
    [ "Candidats", "class_candidats.html", "class_candidats" ],
    [ "Solucio", "class_solucio.html", "class_solucio" ],
    [ "Solucionador", "class_solucionador.html", "class_solucionador" ]
];